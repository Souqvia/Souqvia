import React from 'react';
import { Language } from '../types';

interface Props {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
}

const LanguageSwitcher: React.FC<Props> = ({ currentLang, onLanguageChange }) => {
  return (
    <div className="flex space-x-2 bg-gray-100 p-1 rounded-lg border border-gray-200">
      {(['en', 'fr', 'ar'] as Language[]).map((lang) => (
        <button
          key={lang}
          onClick={() => onLanguageChange(lang)}
          className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
            currentLang === lang
              ? 'bg-white text-dzgreen-700 shadow-sm border border-gray-100'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          {lang.toUpperCase()}
        </button>
      ))}
    </div>
  );
};

export default LanguageSwitcher;