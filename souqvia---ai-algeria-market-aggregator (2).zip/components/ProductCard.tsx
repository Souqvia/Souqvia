
import React from 'react';
import { Product, Translation } from '../types';
import { ShoppingBag, MapPin, Star, ShieldCheck } from 'lucide-react';

interface Props {
  product: Product;
  onClick: (product: Product) => void;
  t: Translation;
  lang: string;
}

const ProductCard: React.FC<Props> = ({ product, onClick, t, lang }) => {
  const isRtl = lang === 'ar';

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat(lang === 'ar' ? 'ar-DZ' : 'fr-DZ', {
      style: 'currency',
      currency: 'DZD',
      maximumFractionDigits: 0,
    }).format(price);
  };

  const getStoreStyles = (store: string) => {
    switch (store) {
      case 'Jumia': return 'bg-orange-50 text-orange-600 border-orange-100';
      case 'Ouedkniss': return 'bg-blue-50 text-blue-600 border-blue-100';
      case 'Facebook Marketplace': return 'bg-sky-50 text-sky-600 border-sky-100';
      default: return 'bg-slate-100 text-slate-600 border-slate-200';
    }
  };

  return (
    <div 
      onClick={() => onClick(product)}
      className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden cursor-pointer hover:shadow-xl hover:-translate-y-1 transition-all group flex flex-col h-full"
    >
      <div className="relative aspect-[4/4] overflow-hidden bg-slate-50">
        <img 
          src={product.imageUrl} 
          alt={product.name} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className={`absolute top-3 ${isRtl ? 'left-3' : 'right-3'} flex flex-col gap-2 items-end`}>
          <span className={`text-[10px] px-2.5 py-1 rounded-lg font-bold uppercase tracking-wider border backdrop-blur-md shadow-sm ${getStoreStyles(product.store)}`}>
            {product.store}
          </span>
          {product.condition === 'New' && (
             <span className="bg-emerald-500 text-white text-[9px] px-2 py-0.5 rounded-md font-black uppercase tracking-widest shadow-lg shadow-emerald-200">
               New
             </span>
          )}
        </div>
        <div className="absolute bottom-3 left-3 flex gap-1">
             <div className="bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg text-[10px] font-bold text-slate-900 shadow-sm flex items-center gap-1">
                <Star size={10} className="text-amber-400 fill-amber-400"/> {product.rating}
             </div>
        </div>
      </div>
      
      <div className="p-5 flex-1 flex flex-col">
        <h3 className="font-bold text-slate-900 line-clamp-2 text-sm md:text-base mb-2 group-hover:text-brand-primary transition-colors leading-snug">
            {product.name}
        </h3>
        
        <div className="flex items-center text-xs text-slate-400 font-medium mb-4">
            <MapPin size={12} className={`mr-1 text-slate-300`} />
            <span>{product.location}</span>
        </div>

        <div className="mt-auto pt-4 border-t border-slate-50 flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-lg font-black text-slate-900 tracking-tight">{formatPrice(product.price)}</span>
            <div className="flex items-center gap-1 text-[10px] text-emerald-600 font-bold uppercase tracking-tight">
                <ShieldCheck size={10} /> {product.sellerName || 'Verified'}
            </div>
          </div>
          <button className="w-10 h-10 bg-slate-900 text-white rounded-xl flex items-center justify-center hover:bg-brand-primary transition-all active:scale-90 shadow-lg shadow-slate-100">
             <ShoppingBag size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
