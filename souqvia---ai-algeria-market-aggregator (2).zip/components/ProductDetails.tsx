import React from 'react';
import { Product, Translation } from '../types';
import { ShoppingBag, MapPin, Star, ShieldCheck, Phone, ArrowLeft, ExternalLink, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Props {
  product: Product;
  t: Translation;
  lang: string;
}

const ProductDetails: React.FC<Props> = ({ product, t, lang }) => {
  const navigate = useNavigate();
  const isRtl = lang === 'ar';

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat(lang === 'ar' ? 'ar-DZ' : 'fr-DZ', {
      style: 'currency',
      currency: 'DZD',
      maximumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div className={`min-h-screen bg-gray-50 pb-20 ${isRtl ? 'rtl' : 'ltr'}`}>
      {/* Sticky Header */}
      <div className="bg-white sticky top-0 z-10 px-4 py-3 shadow-sm flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-full">
            <ArrowLeft className={isRtl ? 'rotate-180' : ''} />
        </button>
        <h1 className="font-semibold text-lg line-clamp-1 flex-1">{product.name}</h1>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-6">
        
        {/* Main Product Card */}
        <div className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-200">
            <div className="aspect-video w-full bg-gray-100 relative">
                <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
                <span className="absolute bottom-4 right-4 bg-slate-900/80 text-white px-3 py-1 rounded-full text-sm font-medium backdrop-blur-sm">
                    {product.store}
                </span>
            </div>
            
            <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                    <div>
                        <h2 className="text-2xl font-bold text-gray-900 mb-2">{product.name}</h2>
                        <div className="flex items-center text-gray-500 text-sm gap-4">
                            <span className="flex items-center gap-1"><MapPin size={14}/> {product.location}</span>
                            <span className="flex items-center gap-1"><Star size={14} className="text-yellow-500 fill-current"/> {product.rating}</span>
                            <span className="bg-gray-100 px-2 py-0.5 rounded text-xs">{product.condition}</span>
                        </div>
                    </div>
                    <div className="text-right">
                        <div className="text-2xl font-bold text-dzgreen-600">{formatPrice(product.price)}</div>
                        <div className="text-xs text-gray-400">Fixed Price</div>
                    </div>
                </div>

                <hr className="my-4 border-gray-100" />

                <div className="space-y-4">
                    <h3 className="font-semibold text-gray-900">{t.description}</h3>
                    <p className="text-gray-600 leading-relaxed">
                        {product.description || "No detailed description available. Please contact the seller for more information."}
                    </p>
                </div>
            </div>
        </div>

        {/* Seller Info & Action */}
        <div className="grid md:grid-cols-2 gap-6">
            
            {/* Seller Card */}
            <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-200">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <User size={20} className="text-gray-400"/> {t.seller}
                </h3>
                <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center text-xl font-bold text-gray-500">
                        {product.sellerName?.[0] || 'S'}
                    </div>
                    <div>
                        <div className="font-bold">{product.sellerName || 'Unknown Seller'}</div>
                        <div className="text-xs text-green-600 flex items-center gap-1">
                            <ShieldCheck size={12}/> Verified Seller
                        </div>
                    </div>
                </div>
                <div className="flex gap-3">
                    <button className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-colors">
                        <Phone size={18}/> {t.callSeller}
                    </button>
                    <a 
                        href={product.externalLink || '#'} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex-1 bg-dzgreen-600 hover:bg-dzgreen-700 text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-colors"
                    >
                        <ExternalLink size={18} /> {t.buyNow}
                    </a>
                </div>
            </div>

            {/* Safety Tips */}
            <div className="bg-orange-50 p-5 rounded-2xl border border-orange-100">
                <h3 className="font-semibold text-orange-800 mb-2 flex items-center gap-2">
                    <ShieldCheck size={20}/> Safety First
                </h3>
                <p className="text-orange-700 text-sm leading-relaxed mb-4">
                    {t.safetyTip}
                </p>
                <ul className="list-disc list-inside text-xs text-orange-700/80 space-y-1">
                    <li>Meet in a public place.</li>
                    <li>Check the item before paying.</li>
                    <li>Avoid direct bank transfers.</li>
                </ul>
            </div>
        </div>

      </div>
    </div>
  );
};

export default ProductDetails;