import { GoogleGenAI, Type } from "@google/genai";
import { Product, SearchFilters, Language } from "../types";

export const searchProductsWithGemini = async (
  query: string, 
  filters: SearchFilters,
  lang: Language
): Promise<Product[]> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    let prompt = `Act as a search engine for Algerian e-commerce. Search query: "${query}". 
    Target market: Algeria. Currency: DZD.
    Generate 8 realistic product listings that would appear on sites like Jumia DZ, Ouedkniss, or Facebook Marketplace DZ.
    Language: ${lang === 'ar' ? 'Arabic' : (lang === 'fr' ? 'French' : 'English')}.
    Include realistic seller names (e.g., "Amine Phone", "Boutique Oran").
    `;

    if (filters.minPrice) prompt += ` Min Price: ${filters.minPrice} DZD.`;
    if (filters.maxPrice) prompt += ` Max Price: ${filters.maxPrice} DZD.`;
    if (filters.location) prompt += ` Location (Wilaya): ${filters.location}.`;
    if (filters.condition) prompt += ` Condition: ${filters.condition}.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              name: { type: Type.STRING },
              price: { type: Type.NUMBER },
              currency: { type: Type.STRING },
              description: { type: Type.STRING },
              store: { type: Type.STRING, enum: ['Jumia', 'Ouedkniss', 'Facebook Marketplace', 'Uno', 'Generic'] },
              condition: { type: Type.STRING, enum: ['New', 'Used', 'Refurbished'] },
              location: { type: Type.STRING },
              rating: { type: Type.NUMBER },
              category: { type: Type.STRING },
              sellerName: { type: Type.STRING },
              externalLink: { type: Type.STRING },
            },
            required: ['id', 'name', 'price', 'store', 'location', 'condition', 'description', 'sellerName'],
          },
        },
      },
    });

    const products = JSON.parse(response.text) as Product[];
    
    return products.map((p, idx) => ({
      ...p,
      imageUrl: `https://picsum.photos/400/400?random=${idx + Math.floor(Math.random() * 1000)}`,
      externalLink: p.store === 'Jumia' ? 'https://www.jumia.dz' : (p.store === 'Ouedkniss' ? 'https://www.ouedkniss.com' : 'https://www.facebook.com/marketplace'),
      sellerPhone: '0550123456' // Mock phone
    }));

  } catch (error) {
    console.error("Gemini Search Error:", error);
    return [];
  }
};

export const getSmartRecommendations = async (lang: Language): Promise<Product[]> => {
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = `Generate 4 trending products currently popular in Algeria (Tech, Fashion, or Home). 
        Language: ${lang}. Currency: DZD.`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            id: { type: Type.STRING },
                            name: { type: Type.STRING },
                            price: { type: Type.NUMBER },
                            currency: { type: Type.STRING },
                            description: { type: Type.STRING },
                            store: { type: Type.STRING },
                            condition: { type: Type.STRING },
                            location: { type: Type.STRING },
                            rating: { type: Type.NUMBER },
                            category: { type: Type.STRING },
                            sellerName: { type: Type.STRING },
                        }
                    }
                }
            }
        });

        const data = JSON.parse(response.text) as Product[];
        return data.map((p, idx) => ({
            ...p,
            imageUrl: `https://picsum.photos/400/400?random=${idx + 50}`,
            externalLink: 'https://www.ouedkniss.com',
            sellerPhone: '0770998877'
        }));

    } catch (e) {
        return [];
    }
}